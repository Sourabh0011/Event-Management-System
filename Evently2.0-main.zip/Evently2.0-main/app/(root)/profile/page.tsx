import React from 'react'

const page = () => {
  return (
    <div>
      Profile
    </div>
  )
}

export default page
