import React from 'react'

const EventDetails = () => {
  return (
    <div>
      Event Create Successfully 
    </div>
  )
}

export default EventDetails
